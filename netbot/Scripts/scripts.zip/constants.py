FILEPATH = r"./StatesDB.txt"
LEARNINGMODE = True #Main operating mode
HITSCONST = 4  # how many words match
RELATIONCONST = 3  # connection exists between nodes
SCORECONST = 1  # adding up matching words weight